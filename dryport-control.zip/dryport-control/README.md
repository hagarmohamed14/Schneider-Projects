# DryPort Control – Operations & BI

Single-file dry port control dashboard (no build step, no dependencies).

- **Overview** – interactive operations map with hotspots
- **Operations** – containers, yard, gates, rail, warehouse, customs, trucks
- **Orders & Customers**, **Finance** (incl. Energy & Utilities)
- **Energy Management** – electricity, water, fuel, solar, cost, targets, alerts, equipment
- **Analytics & Reports**, **Alerts & Settings**
- Light / dark mode toggle (saved in the browser)

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Push this folder to a GitHub repository (branch `main`).
2. In the repo go to **Settings → Pages → Source → GitHub Actions**.
3. The included workflow deploys the site on every push.

## Structure
```
index.html          the whole application
assets/             logo source files (already embedded in index.html)
.github/workflows/  GitHub Pages deploy
```
